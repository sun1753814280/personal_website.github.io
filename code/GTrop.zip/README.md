# GTrop
This is the repository of the corresponding papar 'A global model for estimating tropospheric delay and weighted mean temperature developed with atmospheric reanalysis data from 1979 to 2017'.
