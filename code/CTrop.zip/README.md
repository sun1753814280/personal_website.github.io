# CTrop
This is the corresponding repository of the paper "An ERA5-based model for estimating tropospheric delay and weighted mean temperature over China with improved spatiotemporal resolutions".
